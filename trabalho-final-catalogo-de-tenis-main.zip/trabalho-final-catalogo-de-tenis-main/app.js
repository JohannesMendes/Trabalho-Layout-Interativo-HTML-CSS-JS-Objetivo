// Estado principal: catálogo
/** @typedef {{id:number, brand:string, model:string, size:number, price:number, stock:boolean, favorite:boolean, colors:string[]}} Shoe */
const catalog = /** @type {Shoe[]} */ ([]);

// Filtros/ordenação
const state = {
  search: "",
  brand: "",
  size: "",
  maxPrice: "",
  sort: "",
  onlyFav: false,
  onlyStock: true,
};

// Seletores
const grid = document.getElementById("cardsGrid");
const searchInput = document.getElementById("searchInput");
const brandSelect = document.getElementById("brandSelect");
const sizeSelect = document.getElementById("sizeSelect");
const maxPriceInput = document.getElementById("maxPriceInput");
const sortSelect = document.getElementById("sortSelect");
const onlyFavInput = document.getElementById("onlyFavInput");
const onlyStockInput = document.getElementById("onlyStockInput");
const seedBtn = document.getElementById("seedBtn");
const clearBtn = document.getElementById("clearBtn");

// Relatório
const countSpan = document.getElementById("countSpan");
const favSpan = document.getElementById("favSpan");
const avgPriceSpan = document.getElementById("avgPriceSpan");
const stockSpan = document.getElementById("stockSpan");

// Util: id incremental
let seq = 1;
const nextId = () => seq++;

// Fábrica de objetos
function Shoe({ brand, model, size, price, stock = true, favorite = false, colors = [] }) {
  return { id: nextId(), brand, model, size, price, stock, favorite, colors };
}

// Render
function render() {
  grid.innerHTML = "";

  // Filtrar
  let items = catalog.filter(s => {
    const text = `${s.brand} ${s.model}`.toLowerCase();
    const matchesSearch = text.includes(state.search.toLowerCase());
    const matchesBrand = !state.brand || s.brand === state.brand;
    const matchesSize = !state.size || String(s.size) === state.size;
    const matchesPrice = !state.maxPrice || s.price <= Number(state.maxPrice);
    const matchesFav = !state.onlyFav || s.favorite;
    const matchesStock = !state.onlyStock || s.stock;
    return matchesSearch && matchesBrand && matchesSize && matchesPrice && matchesFav && matchesStock;
  });

  // Ordenar
  const sortBy = state.sort;
  if (sortBy === "price-asc") items.sort((a, b) => a.price - b.price);
  if (sortBy === "price-desc") items.sort((a, b) => b.price - a.price);
  if (sortBy === "name-asc") items.sort((a, b) => (a.model + a.brand).localeCompare(b.model + b.brand));
  if (sortBy === "name-desc") items.sort((a, b) => (b.model + b.brand).localeCompare(a.model + a.brand));

  // Cards
  items.forEach(s => {
    const card = document.createElement("article");
    card.className = "card";
    card.dataset.id = String(s.id);

    const colors = s.colors.map(c => `<span class="badge">${c}</span>`).join("");
    const stockBadge = s.stock ? `<span class="badge">Em estoque</span>` : `<span class="badge" style="border-color:#5b2730;color:#fb7185;">Sem estoque</span>`;

    card.innerHTML = `
      <div class="thumb">${s.brand} • ${s.model}</div>
      <h3>${s.model}</h3>
      <div class="meta">
        <span><strong>Marca:</strong> ${s.brand}</span>
        <span><strong>Número:</strong> ${s.size}</span>
      </div>
      <div class="meta">
        <span><strong>Preço:</strong> R$ ${s.price}</span>
        <span>${stockBadge}</span>
      </div>
      <div class="badges">${colors}</div>
      <div class="actions">
        <button class="fav" aria-pressed="${s.favorite}">
          ${s.favorite ? "★ Favorito" : "☆ Favoritar"}
        </button>
        <button class="cart">${s.stock ? "Adicionar ao carrinho" : "Notificar"}</button>
        <button class="del">Remover</button>
      </div>
    `;

    // Feedback: preço baixo ok, muito alto err
    if (s.price <= 300) card.classList.add("ok");
    if (s.price > 1200) card.classList.add("err");

    grid.appendChild(card);
  });

  updateReport();
}

// Report
function updateReport() {
  countSpan.textContent = String(catalog.length);
  favSpan.textContent = String(catalog.filter(s => s.favorite).length);
  const avg = catalog.length
    ? Math.round(catalog.reduce((acc, s) => acc + s.price, 0) / catalog.length)
    : 0;
  avgPriceSpan.textContent = String(avg);
  stockSpan.textContent = String(catalog.filter(s => s.stock).length);
}

// Delegação de eventos nos cards
grid.addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  const card = e.target.closest(".card");
  const id = Number(card?.dataset.id);
  const idx = catalog.findIndex(s => s.id === id);
  if (idx === -1) return;

  // Favoritar
  if (btn.classList.contains("fav")) {
    catalog[idx].favorite = !catalog[idx].favorite;
    card.classList.add("fav-pulse");
    setTimeout(() => card.classList.remove("fav-pulse"), 500);
    render();
  }

  // Carrinho / Notificar
  if (btn.classList.contains("cart")) {
    if (!catalog[idx].stock) {
      card.classList.add("err");
      setTimeout(() => card.classList.remove("err"), 450);
    } else {
      card.classList.add("ok");
      setTimeout(() => card.classList.remove("ok"), 900);
    }
  }

  // Remover
  if (btn.classList.contains("del")) {
    card.classList.add("removing");
    setTimeout(() => {
      catalog.splice(idx, 1);
      render();
    }, 240);
  }
});

// Filtros: múltiplos eventos
searchInput.addEventListener("keyup", (e) => {
  state.search = e.target.value;
  render();
});
brandSelect.addEventListener("change", (e) => {
  state.brand = e.target.value;
  render();
});
sizeSelect.addEventListener("change", (e) => {
  state.size = e.target.value;
  render();
});
maxPriceInput.addEventListener("input", (e) => {
  state.maxPrice = e.target.value;
  render();
});
sortSelect.addEventListener("change", (e) => {
  state.sort = e.target.value;
  render();
});
onlyFavInput.addEventListener("change", (e) => {
  state.onlyFav = e.target.checked;
  render();
});
onlyStockInput.addEventListener("change", (e) => {
  state.onlyStock = e.target.checked;
  render();
});

// Teclado global: Enter foca busca, Esc limpa filtros
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.target.closest("input,select,button,textarea")) {
    searchInput.focus();
  }
  if (e.key === "Escape") {
    searchInput.value = "";
    brandSelect.value = "";
    sizeSelect.value = "";
    maxPriceInput.value = "";
    sortSelect.value = "";
    onlyFavInput.checked = false;
    onlyStockInput.checked = true;

    state.search = "";
    state.brand = "";
    state.size = "";
    state.maxPrice = "";
    state.sort = "";
    state.onlyFav = false;
    state.onlyStock = true;
    render();
  }
});

// Ações: seed e limpar favoritos
seedBtn.addEventListener("click", () => {
  if (catalog.length) return;
  [
    { brand: "Nike", model: "Air Max 90", size: 41, price: 799, colors: ["preto", "vermelho"] },
    { brand: "Adidas", model: "Ultraboost 22", size: 42, price: 999, colors: ["branco", "azul"] },
    { brand: "Puma", model: "RS-X", size: 40, price: 649, colors: ["preto", "verde"] },
    { brand: "New Balance", model: "574 Core", size: 43, price: 579, colors: ["cinza"] },
    { brand: "Asics", model: "Gel-Kayano 29", size: 42, price: 1299, colors: ["azul", "amarelo"] },
    { brand: "Vans", model: "Old Skool", size: 39, price: 389, colors: ["preto", "branco"] },
    { brand: "Converse", model: "Chuck Taylor", size: 38, price: 349, colors: ["branco"] },
    { brand: "Nike", model: "Jordan 1 Mid", size: 41, price: 1199, colors: ["vermelho", "branco"] },
    { brand: "Adidas", model: "Forum Low", size: 40, price: 599, colors: ["azul"] },
    { brand: "Puma", model: "Suede Classic", size: 42, price: 399, colors: ["preto"] },
  ].forEach(x => catalog.push(Shoe(x)));
  render();
});

clearBtn.addEventListener("click", () => {
  catalog.forEach(s => s.favorite = false);
  render();
});

// Primeira render
render();
